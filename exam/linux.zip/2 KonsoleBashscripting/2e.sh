#!/bin/bash

if !(test $# -eq 3)
then
	echo "not 3"
else
	echo "3"
fi

