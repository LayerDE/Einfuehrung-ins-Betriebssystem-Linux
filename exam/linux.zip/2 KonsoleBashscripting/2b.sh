#!/bin/bash

if test $b == "demo"
then
	echo "is demo"
else
	echo "isn't demo"
fi

