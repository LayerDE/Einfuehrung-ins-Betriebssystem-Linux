#!/bin/bash

expr 3 \* 7 + 5