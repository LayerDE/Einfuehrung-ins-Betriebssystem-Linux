#!/bin/bash

if test $b -le 42 
then
	echo "<=42"
else
	echo ">=42"
fi

