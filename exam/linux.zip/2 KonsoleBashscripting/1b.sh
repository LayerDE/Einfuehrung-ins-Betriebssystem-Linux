#!/bin/bash
y=8
x=$(expr $y + 2)
echo $x
