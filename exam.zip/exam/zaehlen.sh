#!/bin/bash

while read line;
do
  # Implement me!
done < ./begriffe.txt

